package primerParcial;

public class Main {

    public static void main(String[] args) {

        Punto3D primerPunto = new Punto3D(3 , 4 , 9);
        Punto3D segundoPunto = new Punto3D(9 , 4 , 3);
        Punto3D tercerPunto = new Punto3D(6 );
        System.out.println(primerPunto);
        System.out.println(segundoPunto);
        System.out.println(tercerPunto);



    }
}
